﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BildelarKT5
{
    public abstract class Del
    {
        public string DelNummer { get; set; }
        public string ProduktNamn { get; set; }
        public double Pris { get; set; }
        public string Tillverkare { get; set; }

        public Del(string delNummer, string produktnamn, double pris,
            string tillverkare) 
        {
            DelNummer = delNummer;
            ProduktNamn = produktnamn;
            Pris = pris;
            Tillverkare = tillverkare;
        }

        public virtual string DisplayInfo()
        {
            return "Del nummer: " + DelNummer + ", Produktnamn: "+
                ProduktNamn + ", Pris: " + Pris +
                ", Tillverkare: " + Tillverkare ;
        }

        public abstract string ShoppingStrategy();
    }
}

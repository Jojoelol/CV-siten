﻿using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BildelarKT5
{
    public partial class Form1 : Form
    {
        ArrayList Delar = new ArrayList();
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Del delObj = null;

            if (comboBox1.SelectedItem.Equals("MotorOlja"))
            {
                delObj = new MotorOlja(tbDelNummer.Text, tbNamn.Text,
                    Convert.ToDouble(tbPris.Text), tbTillverkare.Text, 
                    tbOljaTyp.Text, tbViskositet.Text);
            }

            if (comboBox1.SelectedItem.Equals("Däck"))
            {
                delObj = new Dack(tbDelNummer.Text, tbNamn.Text,
                    Convert.ToDouble(tbPris.Text), tbTillverkare.Text,
                    Convert.ToInt32(tbBredd.Text),
                    Convert.ToInt32(tbHojd.Text),
                    Convert.ToInt32(tbDiameter.Text),
                    tbArsTid.Text); 
            }

            Delar.Add(delObj);                     //både motorolje- och däck- objekt är ju också av typen Del (eftersom de ärver) 
                                                   //MEN här lagras de i samlingen som objekt av typen Object!     
            PopulateListBoxMedDelar();
        }

        private void PopulateListBoxMedDelar()
        {
            lbDelar.Items.Clear();
            for (int i=0; i<Delar.Count;i++)
            {
                Del del = (Del)Delar[i];            //här sker en cast, dvs en typkonvertering frpn det som finns i samlingen till klassen Del. 
                lbDelar.Items.Add(del.DelNummer);   //Det är förstås bara data som verligen "är" en Del som kan konverteras till denn typen 
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedItem.Equals("MotorOlja"))
            {
                panelMotorOlja.Visible = true;
                panelDäck.Visible = false;

                tbDelNummer.Text = "134294";
                tbNamn.Text = "Mobil ESP1 1 Motorolja";
                tbPris.Text = 615.ToString();
                tbTillverkare.Text = "Mobil";

                tbOljaTyp.Text = "Helsyntetisk olja";
                tbViskositet.Text = "5W-30";
            }

            if (comboBox1.SelectedItem.Equals("Däck"))
            {
                panelMotorOlja.Visible = false;
                panelDäck.Visible = true;

                tbDelNummer.Text = "401927";
                tbNamn.Text = "Continental CONTISPORTCONTACT 3";
                tbPris.Text = 2131.ToString();
                tbTillverkare.Text = "Continental";

                tbBredd.Text = 275.ToString();
                tbHojd.Text = 35.ToString();
                tbDiameter.Text =18.ToString();
                tbArsTid.Text ="Sommar";
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            panelMotorOlja.Visible = false;
            panelDäck.Visible = false;
        }
    }
}

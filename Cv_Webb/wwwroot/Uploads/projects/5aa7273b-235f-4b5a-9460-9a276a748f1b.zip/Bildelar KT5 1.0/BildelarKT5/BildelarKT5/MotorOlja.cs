﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BildelarKT5
{
    public class MotorOlja : Del
    {
        public string OljaTyp { get; set; }
        public string Viskositetsklass { get; set; }

        public MotorOlja(string delNummer, string produktnamn, double pris, 
            string tillverkare, string oljaTyp, string viskositetsKlass)
            : base(delNummer, produktnamn, pris, tillverkare)
        {
            OljaTyp = oljaTyp;
            Viskositetsklass = viskositetsKlass;
        }

        public override string DisplayInfo()
        {
            return base.DisplayInfo() + ", OljaTyp: " + OljaTyp +
                ", Viskositetsklass: " + Viskositetsklass;
        }

        public override string ShoppingStrategy()
        {
            return "Online";
        }
    }
}
